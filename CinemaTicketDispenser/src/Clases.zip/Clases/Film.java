package Clases;




import java.io.File;
import java.io.Serializable;

public class Film implements Serializable {

    private String name;
    private File  poster;
    private int duration;
    private String description;
    
    public File img =new File("C:/Users/MARIO/Pictures/ciclos.PNG");
    
    
    public Film(String name,File poster, int duration,String description){
        this.name=name;
        this.poster=poster;
        this.duration=duration;
        this.description=description;
    
    
    }

    Film() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public String getName(){
        return name;
    
    }
    
    public File getPoster(){
        return poster;
    
    }
    
    
    public int getDuration(){
        return duration;
    
    }
    
    
    public String getDescription(){
        return description;
    
    }
    
    
    



    
}
