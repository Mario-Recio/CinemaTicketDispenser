
package Clases;

import sienens.CinemaTicketDispenser;
import urjc.UrjcBankServer;


public class PerformPayment extends Operation {
    UrjcBankServer bank= new UrjcBankServer();



public void doOperation(){
  


}


public void PerformPayment( CinemaTicketDispenser cine, Multiplex mul){



}




    
}
