
package Clases;

import java.io.Serializable;


public class Seat implements Serializable {

    private int row;
    private int col;

 
    
    
    public void seat(int row,int col){



    }
}
