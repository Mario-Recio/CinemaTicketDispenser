
package Clases;

import Clases.Film;
import Clases.Multiplex;
import Clases.MultiplexState;
import Clases.Operation;
import Clases.PerformPayment;
import Clases.Session;
import Clases.Theater;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import sienens.CinemaTicketDispenser;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;



public class MovieTicketSale extends Operation   {
    
    //MultiplexState state= new MultiplexState(dispenser,bank);
    PerformPayment payment= new PerformPayment();
    CinemaTicketDispenser dispenser= new CinemaTicketDispenser();
    MainMenu menu=new MainMenu();
    String pelicula;
    int sala;
    
    
   


    public void doOperation (){
        int i=0;
        String direccion=" ";
        dispenser.setTitle("URJC Cinema - Seleccione una pelicula");
        for (i=0;i<=3;i++){
            if(i==0){
                direccion=("C:/Users/MARIO/Desktop/Segundo/POO/Implementacion Practica/Movie1.txt");
                Film pelicula1= new Film();
                Theater sala1= new Theater();
                Session[] sesion1= new Session [3];
                try {
                    cargarDatos(direccion,pelicula1,sala1,sesion1);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            }
            else if(i==1){
                direccion=("C:/Users/MARIO/Desktop/Segundo/POO/Implementacion Practica/Movie2.txt");
                Film pelicula2= new Film();
                Theater sala2= new Theater();
                Session[] sesion2= new Session [3];
                try {
                    cargarDatos(direccion,pelicula2,sala2,sesion2);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            
            }
            else if(i==2){
                direccion=("C:/Users/MARIO/Desktop/Segundo/POO/Implementacion Practica/Movie3.txt");
                Film pelicula3= new Film();
                Theater sala3= new Theater();
                Session[] sesion3= new Session [3];
                try {
                    cargarDatos(direccion,pelicula3,sala3,sesion3);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            
            }
            else{
                direccion=("C:/Users/MARIO/Desktop/Segundo/POO/Implementacion Practica/Movie4.txt");
                Film pelicula4= new Film();
                Theater sala4= new Theater();
                Session[] sesion4= new Session [3];
                try {
                    cargarDatos(direccion,pelicula4,sala4,sesion4);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(MovieTicketSale.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            } 
        
        }
        menu.presentMenu();
            
            /*if (c == 'A') {   
                
            } else if (c == 'B') {
                 
            } else if (c == 'C') {
                
            } else if (c == 'D') {
                                   
            }*/
    }
    
    private void cargarDatos(String direccion, Film pelicula, Theater sala, Session[] sesion) throws FileNotFoundException, IOException {
            
            FileReader grifoFichero = new FileReader(direccion);
            BufferedReader reader= new BufferedReader(grifoFichero);
            boolean found=false;
            
            int eof = grifoFichero.read();
            
            while( (eof!=-1)||(!found)){
                 if("Theater:".equals(sala)){
                    sala = reader.readLine();
                    found=true;
                }
            }
            String aux;
            
            while( ((aux = reader.readLine())!=null)||(!found)){
                 if("Title:".equals(aux)){
                    reader.readLine();
                    while (aux!=("When" || "Drama")
                     pelicula = reader.readLine();
                    found=true;
                }
            }
    }
    
    
    
    
    public void MovieTicketSale(CinemaTicketDispenser dispenser, Multiplex mul){
    
    
    }
    
    
    
    /*private Theater selectTheather(){
    
    return Theater;
    }*/
    
    
    private void selectSeats(Theater sala, Session sesion){
    
    
    }
    
    
    
    /*private Session selectSession(Theater sala){
    
    
    
    return Session;
    }*/
    
    
    /*private boolean performPayment(){
    
    
    return boolean;
    }*/
    
    
    
    private void presentSeats(){
    
    
    
    
    }
    
    private void computePrice(){
    
    
    
    }
    
    
    public String selectTitle(String direccion) throws FileNotFoundException, IOException{
        
        
            FileReader grifoFichero = new FileReader(direccion);
            BufferedReader reader= new BufferedReader(grifoFichero);
            boolean found=false;
            
            int eof = grifoFichero.read();
            
            while( (eof!=-1)||(!found)){
                 if("Theater:".equals(sala)){
                    sala = reader.readLine();
                    found=true;
                }
            }
            String aux;
            
            while( ((aux = reader.readLine())!=null)||(!found)){
                 if("Title:".equals(aux)){
                    reader.readLine();
                    while (aux!=("When" || "Drama")
                     pelicula = reader.readLine();
                    found=true;
                }
            }
            return pelicula;
    }
    
    
    
    public void serializeMultiplexState(){
    
    
    
    }
    
   
    
    /*public String getTitle(){
    
    return;
    }*/
    
    public void deserializeMultiplexState(){
    
    
    }

    
        
    
    
    
    
    
    
    


    
}
