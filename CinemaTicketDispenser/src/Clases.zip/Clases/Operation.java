
package Clases;
import sienens.CinemaTicketDispenser;
import urjc.UrjcBankServer;


public class Operation {
  
    Multiplex atm = new Multiplex();
    CinemaTicketDispenser dispenser= new CinemaTicketDispenser();
    UrjcBankServer bank = new UrjcBankServer();
    
    
    public void doOperation(){


    }
    
    public void Operation(CinemaTicketDispenser dispenser,Multiplex mul ){
    
    
   
    }
    
    
    public CinemaTicketDispenser getDispenser(){
    
    
     return dispenser;
    }
    
    
    /*public String getTitle(){
    
    
    return
    }*/
    
    public Multiplex getMultiplex(){
    
    
    return atm;
    }
    
    
}
