
package Clases;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import sienens.CinemaTicketDispenser;
import urjc.UrjcBankServer;


public class MultiplexState implements Serializable {


    private Theater theater;
    private List<Theater> theaterList= new ArrayList<>();
    
    
    
    public MultiplexState(CinemaTicketDispenser dispenser, UrjcBankServer bank){
    
    
    }
    
    
    public void loadMoviesAndSessions(){
    
    
    
    
    }

    public Theater getTheater(int sala) {
        return theater;
    }

    
    /*public int getNumberOfTheathers(){
    
    
    return int;
    }*/
    
    
    public List<Theater> getTheaterList() {
        return theaterList;
    }
    
    
    
    
}
