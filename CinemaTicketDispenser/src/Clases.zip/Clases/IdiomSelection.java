
package Clases;

import sienens.CinemaTicketDispenser;


public class IdiomSelection extends Operation {
    
    
    
    public void doOperation(){
    
    
    
    
    }
    
    public void IdiomSelection(CinemaTicketDispenser dispenser, Multiplex mul){
    
    
    }
    
    
    /*public String getTitle(){
    
    
    return;
    }*/
    
    
}
