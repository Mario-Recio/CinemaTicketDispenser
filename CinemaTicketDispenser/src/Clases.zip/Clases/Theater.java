
package Clases;

import java.util.Set;
import java.util.TreeSet;


public class Theater {
    
    private int number;
    private int price;
    private Set<Seat> seatSet= new TreeSet<>();
    private Film film; /*podria ser lista*/
    private Session session;
    private Seat seat;
    

    public Theater(int number, int price, Film filmList) {
        this.number = number;
        this.price = price;
        this.film = filmList;
    }

    Theater() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getNumber() {
        return number;
    }

    public int getPrice() {
        return price;
    }

    public void addSession(){
    
    
    }
    
    public Film getFilmt() {
        return film;
    }
    
    
    public Session getSessionList(){
    
    
    return session;
    }
    
    
    public Set<Seat> getSeatSet() {
        return seatSet;
    }

    
    /*public int getMaxrows(){
    
    
    return int;
    

    /*public int getMaxcols(){
    
    
    return int;
    }*/
    
    
    public void loadSeats(){
    
    
    
    }
   
    
}


