package Clases;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import sienens.CinemaTicketDispenser;
import urjc.UrjcBankServer;

/**
 *
 * @author jvelez
 */
class Multiplex {
    
    private String idiom;
    
    
    CinemaTicketDispenser dispenser = new CinemaTicketDispenser();
    MovieTicketSale venta= new MovieTicketSale();
    MainMenu menu=new MainMenu();
    
    UrjcBankServer bank = new UrjcBankServer();
    int mode = 0;
    
    void start() {         
        
        menu.presentIdioms();
        
        venta.doOperation();
        
      
        
        int rows = (int)(Math.random() * 10)+4;
        int cols = (int)(Math.random() * 16)+4;
        

            
            
            
        
    
    
    
    }
    
    public String getIdiom(){
        
        return idiom;
    }
    
    public void setIdiom(String value){
        
        
    }
}


/*
        while(true) {
dispenser.setTitle("URJC Cinema - Bienvenido");
        dispenser.setOption(0, "Modo cine");
        dispenser.setOption(1, "Comprar palomitas");
        dispenser.setOption(2, "Pulsar este botón solo si hay dentro una tarjeta de crédito, en cuyo caso se la traga definitvamente.");
        dispenser.setOption(3, "Devolver la tarjeta");
        dispenser.setOption(4, "Imprimir entradas\nPelícula Dune");
        dispenser.setOption(5, "Pintar cartel de Dune");*/