
package Clases;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;
import jdk.internal.net.http.common.Pair;


public class Session implements Serializable {
 
    private int hora;
    private int minutos;   
    Seat seat=new Seat();
    private Set <Seat> occupiedSeatSet= new TreeSet<>();
    
    Pair<Integer,Integer> hour= new Pair<>(0,0);
     
    
    public Session(int hora, int minutos) {
        this.hora=hora;
        this.minutos=minutos;
    }

    Session() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    /*public boolean isOccupied(int row, int col){
    
    
    return;
    }*/
    
    
    public void occupiesSeat(int row, int col){
    
    
    }
    
    
    public Pair <Integer,Integer> getHour(){
        return hour;
    }
    
    
    public void setHour(int hora, int minutos){
        hour= new Pair(hora,minutos);
    }
    
    public void unocupiesSeat(int row, int col){
    
    
    }
   
    
    
    
   
    
    
    
    
    
    
    
    
    
 
    
}
